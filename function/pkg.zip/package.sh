pushd .
zip -r pkg.zip *
popd